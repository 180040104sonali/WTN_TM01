
package com.wipro.ccbill.exception;
public class InvalidReadingException extends Exception{
public String toString()
{
return "Incorrect Reading";
}
public InvalidReadingException()
{
super();
}
}
